package com.legacychat.app.ui.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.legacychat.app.R;
import com.legacychat.app.data.ChatRepository;
import com.legacychat.app.models.Chat;
import com.legacychat.app.models.Message;
import com.legacychat.app.ui.adapters.MessageAdapter;

import java.util.List;

/**
 * Activity for displaying chat conversation
 */
public class ChatActivity extends AppCompatActivity {

    public static final String EXTRA_CHAT_ID = "chat_id";
    public static final String EXTRA_CHAT_NAME = "chat_name";

    private String chatId;
    private String chatName;
    private ChatRepository chatRepository;
    private MessageAdapter messageAdapter;
    private RecyclerView recyclerMessages;
    private EditText editMessage;
    private ImageButton btnSend;
    private TextView txtName;
    private TextView txtStatus;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Get intent data
        chatId = getIntent().getStringExtra(EXTRA_CHAT_ID);
        chatName = getIntent().getStringExtra(EXTRA_CHAT_NAME);

        if (chatId == null) {
            finish();
            return;
        }

        // Initialize repository and handler
        chatRepository = new ChatRepository(this);
        handler = new Handler(Looper.getMainLooper());

        // Setup toolbar
        setupToolbar();

        // Setup message list
        setupMessageList();

        // Setup input area
        setupInputArea();

        // Load messages
        loadMessages();
    }

    /**
     * Setup toolbar with navigation and chat info
     */
    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Setup navigation
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // Setup chat info
        txtName = findViewById(R.id.txt_name);
        txtStatus = findViewById(R.id.txt_status);

        txtName.setText(chatName != null ? chatName : "مستخدم");
        txtStatus.setText("متصل الآن");

        // Setup avatar
        ImageView imgAvatar = findViewById(R.id.img_avatar);
        imgAvatar.setImageResource(R.drawable.ic_chat);
    }

    /**
     * Setup RecyclerView for messages
     */
    private void setupMessageList() {
        recyclerMessages = findViewById(R.id.recycler_messages);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true); // Start from bottom
        recyclerMessages.setLayoutManager(layoutManager);

        messageAdapter = new MessageAdapter(this);
        recyclerMessages.setAdapter(messageAdapter);
    }

    /**
     * Setup message input area
     */
    private void setupInputArea() {
        editMessage = findViewById(R.id.edit_message);
        btnSend = findViewById(R.id.btn_send);

        // Initially disable send button
        btnSend.setEnabled(false);
        btnSend.setAlpha(0.5f);

        // Text change listener for send button state
        editMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                boolean hasText = s.toString().trim().length() > 0;
                btnSend.setEnabled(hasText);
                btnSend.setAlpha(hasText ? 1.0f : 0.5f);
            }
        });

        // Send on keyboard action
        editMessage.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });

        // Send button click
        btnSend.setOnClickListener(v -> sendMessage());
    }

    /**
     * Send a message
     */
    private void sendMessage() {
        String content = editMessage.getText().toString().trim();
        if (content.isEmpty()) {
            return;
        }

        // Clear input
        editMessage.setText("");

        // Send message
        String senderId = "me";
        Message message = chatRepository.sendMessage(chatId, senderId, content);

        if (message != null) {
            messageAdapter.addMessage(message);

            // Scroll to bottom
            recyclerMessages.scrollToPosition(messageAdapter.getItemCount() - 1);

            // Simulate message delivery status update
            simulateMessageDelivery(message);
        }
    }

    /**
     * Simulate message delivery status updates
     */
    private void simulateMessageDelivery(Message message) {
        // Simulate sent status after 1 second
        handler.postDelayed(() -> {
            chatRepository.updateMessageStatus(message.getId(), Message.STATUS_SENT);
            messageAdapter.updateMessageStatus(message.getId(), Message.STATUS_SENT);
        }, 1000);

        // Simulate delivered status after 2 seconds
        handler.postDelayed(() -> {
            chatRepository.updateMessageStatus(message.getId(), Message.STATUS_DELIVERED);
            messageAdapter.updateMessageStatus(message.getId(), Message.STATUS_DELIVERED);
        }, 2000);

        // Simulate automatic reply for demo
        handler.postDelayed(() -> {
            simulateReceivedMessage();
        }, 3000);
    }

    /**
     * Simulate receiving a message for demonstration
     */
    private void simulateReceivedMessage() {
        String[] replies = {
                "شكراً على رسالتك!",
                "أنا收到了你的消息",
                "جيد جداً!",
                "هل يمكنك إرسال المزيد من التفاصيل؟",
                "أراك لاحقاً!"
        };

        String randomReply = replies[(int) (Math.random() * replies.length)];
        Message receivedMessage = chatRepository.receiveMessage(chatId, "other", randomReply);

        if (receivedMessage != null) {
            messageAdapter.addMessage(receivedMessage);
            recyclerMessages.scrollToPosition(messageAdapter.getItemCount() - 1);
        }
    }

    /**
     * Load messages for this chat
     */
    private void loadMessages() {
        List<Message> messages = chatRepository.getMessagesForChat(chatId);

        if (messages.isEmpty()) {
            findViewById(R.id.txt_no_messages).setVisibility(android.view.View.VISIBLE);
        } else {
            findViewById(R.id.txt_no_messages).setVisibility(android.view.View.GONE);
            messageAdapter.setMessages(messages);

            // Scroll to bottom
            recyclerMessages.scrollToPosition(messages.size() - 1);
        }
    }
}
