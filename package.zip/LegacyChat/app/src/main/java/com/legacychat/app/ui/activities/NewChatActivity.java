package com.legacychat.app.ui.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.legacychat.app.R;
import com.legacychat.app.data.ChatRepository;
import com.legacychat.app.models.Chat;
import com.legacychat.app.models.Contact;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity for creating a new chat with a contact
 */
public class NewChatActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_READ_CONTACTS = 100;

    private RecyclerView recyclerContacts;
    private ContactAdapter contactAdapter;
    private ChatRepository chatRepository;
    private EditText editSearch;
    private TextView txtEmptyState;
    private List<Contact> allContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Setup toolbar (reusing chat layout for simplicity)
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            toolbar.setNavigationIcon(R.drawable.ic_back);
        }

        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // Setup title
        TextView txtName = findViewById(R.id.txt_name);
        txtName.setText(R.string.start_new_chat);

        // Hide status
        findViewById(R.id.txt_status).setVisibility(View.GONE);

        // Hide chat elements
        findViewById(R.id.recycler_messages).setVisibility(View.GONE);
        findViewById(R.id.layout_input).setVisibility(View.GONE);
        findViewById(R.id.txt_no_messages).setVisibility(View.GONE);

        // Initialize repository
        chatRepository = new ChatRepository(this);

        // Setup search and contact list
        setupSearch();
        setupContactList();

        // Check permissions and load contacts
        checkContactsPermission();
    }

    /**
     * Setup search field
     */
    private void setupSearch() {
        editSearch = new EditText(this);
        editSearch.setHint(R.string.search_contacts);
        editSearch.setPadding(32, 16, 32, 16);
        editSearch.setBackgroundResource(R.drawable.bg_input_field);

        // Add search to the layout
        View searchContainer = findViewById(R.id.img_avatar).getParent() instanceof android.view.ViewGroup ?
                (ViewGroup) findViewById(R.id.img_avatar).getParent() : null;

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                filterContacts(s.toString());
            }
        });
    }

    /**
     * Setup RecyclerView for contacts
     */
    private void setupContactList() {
        recyclerContacts = findViewById(R.id.recycler_messages);
        txtEmptyState = findViewById(R.id.txt_no_messages);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerContacts.setLayoutManager(layoutManager);

        contactAdapter = new ContactAdapter(contact -> {
            // Create new chat with this contact
            Chat chat = chatRepository.createChat(contact.getName(), contact.getPhoneNumber());

            if (chat != null) {
                // Open the new chat
                Intent intent = new Intent(NewChatActivity.this, ChatActivity.class);
                intent.putExtra(ChatActivity.EXTRA_CHAT_ID, chat.getId());
                intent.putExtra(ChatActivity.EXTRA_CHAT_NAME, chat.getName());
                startActivity(intent);
                finish();
            }
        });

        recyclerContacts.setAdapter(contactAdapter);
    }

    /**
     * Check and request contacts permission
     */
    private void checkContactsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    PERMISSION_REQUEST_READ_CONTACTS);
        } else {
            loadContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_READ_CONTACTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadContacts();
            } else {
                txtEmptyState.setText("يرجى منح إذن الوصول للجهات الاتصال");
                txtEmptyState.setVisibility(View.VISIBLE);
            }
        }
    }

    /**
     * Load contacts from device
     */
    private void loadContacts() {
        allContacts = chatRepository.getDeviceContacts();

        if (allContacts.isEmpty()) {
            txtEmptyState.setText(R.string.no_contacts);
            txtEmptyState.setVisibility(View.VISIBLE);
        } else {
            txtEmptyState.setVisibility(View.GONE);
            contactAdapter.setContacts(allContacts);
        }
    }

    /**
     * Filter contacts by search query
     */
    private void filterContacts(String query) {
        if (allContacts == null) {
            return;
        }

        List<Contact> filteredContacts = new ArrayList<>();
        String lowerQuery = query.toLowerCase().trim();

        for (Contact contact : allContacts) {
            String name = contact.getName();
            String phoneNumber = contact.getPhoneNumber();

            if ((name != null && name.toLowerCase().contains(lowerQuery)) ||
                (phoneNumber != null && phoneNumber.contains(query))) {
                filteredContacts.add(contact);
            }
        }

        contactAdapter.setContacts(filteredContacts);

        if (filteredContacts.isEmpty()) {
            txtEmptyState.setText(R.string.no_contacts);
            txtEmptyState.setVisibility(View.VISIBLE);
        } else {
            txtEmptyState.setVisibility(View.GONE);
        }
    }

    /**
     * Simple adapter for displaying contacts
     */
    private class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactViewHolder> {

        private final List<Contact> contacts;
        private final OnContactClickListener listener;

        public interface OnContactClickListener {
            void onContactClick(Contact contact);
        }

        public ContactAdapter(OnContactClickListener listener) {
            this.contacts = new ArrayList<>();
            this.listener = listener;
        }

        @NonNull
        @Override
        public ContactViewHolder onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_chat, parent, false);
            return new ContactViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
            holder.bind(contacts.get(position));
        }

        @Override
        public int getItemCount() {
            return contacts.size();
        }

        public void setContacts(List<Contact> newContacts) {
            contacts.clear();
            contacts.addAll(newContacts);
            notifyDataSetChanged();
        }

        class ContactViewHolder extends RecyclerView.ViewHolder {
            private final TextView txtName;
            private final TextView txtLastMessage;

            ContactViewHolder(@NonNull View itemView) {
                super(itemView);
                txtName = itemView.findViewById(R.id.txt_name);
                txtLastMessage = itemView.findViewById(R.id.txt_last_message);
                txtLastMessage.setText("انقر لبدء محادثة");

                itemView.setOnClickListener(v -> {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onContactClick(contacts.get(position));
                    }
                });
            }

            void bind(Contact contact) {
                txtName.setText(contact.getDisplayName());
            }
        }
    }
}
