package com.legacychat.app.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.legacychat.app.R;
import com.legacychat.app.models.Chat;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter for displaying chat list in RecyclerView
 */
public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private final List<Chat> chats;
    private final OnChatClickListener listener;
    private final Context context;

    public interface OnChatClickListener {
        void onChatClick(Chat chat);
        void onChatLongClick(Chat chat);
    }

    public ChatAdapter(Context context, OnChatClickListener listener) {
        this.context = context;
        this.chats = new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Chat chat = chats.get(position);
        holder.bind(chat);
    }

    @Override
    public int getItemCount() {
        return chats.size();
    }

    public void setChats(List<Chat> newChats) {
        chats.clear();
        chats.addAll(newChats);
        notifyDataSetChanged();
    }

    public void addChat(Chat chat) {
        chats.add(0, chat);
        notifyItemInserted(0);
    }

    public void updateChat(Chat chat) {
        for (int i = 0; i < chats.size(); i++) {
            if (chats.get(i).getId().equals(chat.getId())) {
                chats.set(i, chat);
                notifyItemChanged(i);
                break;
            }
        }
    }

    public void removeChat(String chatId) {
        for (int i = 0; i < chats.size(); i++) {
            if (chats.get(i).getId().equals(chatId)) {
                chats.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }

    class ChatViewHolder extends RecyclerView.ViewHolder {

        private final ImageView imgAvatar;
        private final TextView txtName;
        private final TextView txtTime;
        private final TextView txtLastMessage;
        private final TextView txtUnread;

        ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            imgAvatar = itemView.findViewById(R.id.img_avatar);
            txtName = itemView.findViewById(R.id.txt_name);
            txtTime = itemView.findViewById(R.id.txt_time);
            txtLastMessage = itemView.findViewById(R.id.txt_last_message);
            txtUnread = itemView.findViewById(R.id.txt_unread);

            // Set click listeners
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onChatClick(chats.get(position));
                }
            });

            itemView.setOnLongClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onChatLongClick(chats.get(position));
                    return true;
                }
                return false;
            });
        }

        void bind(Chat chat) {
            // Set name
            txtName.setText(chat.getName());

            // Set time
            txtTime.setText(chat.getFormattedTime());

            // Set last message
            if (chat.getLastMessage() != null && !chat.getLastMessage().isEmpty()) {
                txtLastMessage.setText(chat.getLastMessage());
                txtLastMessage.setVisibility(View.VISIBLE);
            } else {
                txtLastMessage.setVisibility(View.GONE);
            }

            // Set unread count
            if (chat.getUnreadCount() > 0) {
                txtUnread.setText(String.valueOf(chat.getUnreadCount()));
                txtUnread.setVisibility(View.VISIBLE);
            } else {
                txtUnread.setVisibility(View.GONE);
            }

            // Set avatar (placeholder for now)
            imgAvatar.setImageResource(R.drawable.ic_chat);
        }
    }
}
