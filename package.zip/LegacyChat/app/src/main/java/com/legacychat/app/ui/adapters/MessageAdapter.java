package com.legacychat.app.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.legacychat.app.R;
import com.legacychat.app.models.Message;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter for displaying messages in a chat conversation
 */
public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_SENT = 1;
    private static final int VIEW_TYPE_RECEIVED = 2;

    private final List<Message> messages;
    private final Context context;

    public MessageAdapter(Context context) {
        this.context = context;
        this.messages = new ArrayList<>();
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messages.get(position);
        return message.isSent() ? VIEW_TYPE_SENT : VIEW_TYPE_RECEIVED;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_SENT) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_sent, parent, false);
            return new SentMessageViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_received, parent, false);
            return new ReceivedMessageViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messages.get(position);

        if (holder instanceof SentMessageViewHolder) {
            ((SentMessageViewHolder) holder).bind(message);
        } else if (holder instanceof ReceivedMessageViewHolder) {
            ((ReceivedMessageViewHolder) holder).bind(message);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public void setMessages(List<Message> newMessages) {
        messages.clear();
        messages.addAll(newMessages);
        notifyDataSetChanged();
    }

    public void addMessage(Message message) {
        messages.add(message);
        notifyItemInserted(messages.size() - 1);
    }

    public void updateMessageStatus(long messageId, int status) {
        for (int i = 0; i < messages.size(); i++) {
            if (messages.get(i).getId() == messageId) {
                messages.get(i).setStatus(status);
                notifyItemChanged(i);
                break;
            }
        }
    }

    /**
     * ViewHolder for sent messages
     */
    class SentMessageViewHolder extends RecyclerView.ViewHolder {

        private final LinearLayout messageBubble;
        private final TextView txtMessage;
        private final TextView txtTime;
        private final ImageView imgStatus;

        SentMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            messageBubble = itemView.findViewById(R.id.message_bubble);
            txtMessage = itemView.findViewById(R.id.txt_message);
            txtTime = itemView.findViewById(R.id.txt_time);
            imgStatus = itemView.findViewById(R.id.img_status);
        }

        void bind(Message message) {
            txtMessage.setText(message.getContent());
            txtTime.setText(message.getFormattedTime());

            // Set status icon based on message status
            switch (message.getStatus()) {
                case Message.STATUS_SENT:
                    imgStatus.setImageResource(R.drawable.ic_message_sent);
                    break;
                case Message.STATUS_DELIVERED:
                    imgStatus.setImageResource(R.drawable.ic_message_sent);
                    break;
                case Message.STATUS_READ:
                    // Could use different icon for read status
                    imgStatus.setImageResource(R.drawable.ic_message_sent);
                    break;
                default:
                    // Hide status for sending state
                    imgStatus.setVisibility(View.GONE);
                    break;
            }
        }
    }

    /**
     * ViewHolder for received messages
     */
    class ReceivedMessageViewHolder extends RecyclerView.ViewHolder {

        private final LinearLayout messageBubble;
        private final TextView txtSender;
        private final TextView txtMessage;
        private final TextView txtTime;

        ReceivedMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            messageBubble = itemView.findViewById(R.id.message_bubble);
            txtSender = itemView.findViewById(R.id.txt_sender);
            txtMessage = itemView.findViewById(R.id.txt_message);
            txtTime = itemView.findViewById(R.id.txt_time);
        }

        void bind(Message message) {
            txtMessage.setText(message.getContent());
            txtTime.setText(message.getFormattedTime());

            // Hide sender name for individual chats (show for group chats)
            txtSender.setVisibility(View.GONE);
        }
    }
}
