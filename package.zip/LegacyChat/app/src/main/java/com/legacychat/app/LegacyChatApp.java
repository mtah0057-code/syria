package com.legacychat.app;

import android.app.Application;
import android.database.sqlite.SQLiteDatabase;

import com.legacychat.app.data.DatabaseHelper;

/**
 * Application class for LegacyChat
 * Initializes database and other app-wide components
 */
public class LegacyChatApp extends Application {

    private static LegacyChatApp instance;
    private DatabaseHelper databaseHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Initialize database
        databaseHelper = new DatabaseHelper(this);
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // Log database initialization
        android.util.Log.d("LegacyChatApp", "Database initialized successfully");
    }

    public static LegacyChatApp getInstance() {
        return instance;
    }

    public DatabaseHelper getDatabaseHelper() {
        return databaseHelper;
    }
}
