package com.legacychat.app.models;

/**
 * Message model class representing a chat message
 */
public class Message {

    private long id;
    private String chatId;
    private String senderId;
    private String content;
    private long timestamp;
    private int status; // 0 = sending, 1 = sent, 2 = delivered, 3 = read
    private boolean isSent; // true if this message was sent by current user

    // Message status constants
    public static final int STATUS_SENDING = 0;
    public static final int STATUS_SENT = 1;
    public static final int STATUS_DELIVERED = 2;
    public static final int STATUS_READ = 3;

    public Message() {
        this.timestamp = System.currentTimeMillis();
        this.status = STATUS_SENDING;
    }

    public Message(String chatId, String senderId, String content, boolean isSent) {
        this();
        this.chatId = chatId;
        this.senderId = senderId;
        this.content = content;
        this.isSent = isSent;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public boolean isSent() {
        return isSent;
    }

    public void setSent(boolean sent) {
        isSent = sent;
    }

    /**
     * Get formatted time string
     */
    public String getFormattedTime() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
        return sdf.format(new java.util.Date(timestamp));
    }

    /**
     * Get relative time string (e.g., "5 minutes ago")
     */
    public String getRelativeTime() {
        long now = System.currentTimeMillis();
        long diff = now - timestamp;

        if (diff < 60000) {
            return "الآن";
        } else if (diff < 3600000) {
            int minutes = (int) (diff / 60000);
            return minutes + " دقيقة";
        } else if (diff < 86400000) {
            int hours = (int) (diff / 3600000);
            return hours + " ساعة";
        } else {
            int days = (int) (diff / 86400000);
            return days + " أيام";
        }
    }
}
