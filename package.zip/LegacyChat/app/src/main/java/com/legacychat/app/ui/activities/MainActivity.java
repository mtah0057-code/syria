package com.legacychat.app.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;
import com.legacychat.app.R;
import com.legacychat.app.data.ChatRepository;
import com.legacychat.app.models.Chat;
import com.legacychat.app.ui.adapters.ChatAdapter;

/**
 * Main Activity displaying chat list with tabs
 */
public class MainActivity extends AppCompatActivity implements ChatAdapter.OnChatClickListener {

    private RecyclerView recyclerChats;
    private ChatAdapter chatAdapter;
    private ChatRepository chatRepository;
    private TextView txtEmptyState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize repository
        chatRepository = new ChatRepository(this);

        // Setup toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Setup tabs
        setupTabs();

        // Setup chat list
        setupChatList();

        // Setup FAB
        setupFab();

        // Load sample data for demonstration
        loadSampleData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadChats();
    }

    /**
     * Setup TabLayout with tabs
     */
    private void setupTabs() {
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        ViewPager viewPager = findViewById(R.id.view_pager);

        // Add tabs
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_chats));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_status));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_calls));

        // Setup simple page adapter (for demo, just showing tabs)
        // In production, this would have FragmentPagerAdapter with actual fragments
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Handle tab selection
                if (tab.getPosition() == 0) {
                    recyclerChats.setVisibility(View.VISIBLE);
                } else {
                    recyclerChats.setVisibility(View.GONE);
                    txtEmptyState.setText("قريباً...");
                    txtEmptyState.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    /**
     * Setup RecyclerView for chat list
     */
    private void setupChatList() {
        recyclerChats = findViewById(R.id.recycler_messages);
        txtEmptyState = findViewById(R.id.txt_no_messages);

        // Setup RecyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerChats.setLayoutManager(layoutManager);

        // Create adapter
        chatAdapter = new ChatAdapter(this, this);
        recyclerChats.setAdapter(chatAdapter);
    }

    /**
     * Setup Floating Action Button
     */
    private void setupFab() {
        findViewById(R.id.fab_new_chat).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NewChatActivity.class);
            startActivity(intent);
        });
    }

    /**
     * Load chats from database
     */
    private void loadChats() {
        java.util.List<Chat> chats = chatRepository.getAllChats();

        if (chats.isEmpty()) {
            recyclerChats.setVisibility(View.GONE);
            txtEmptyState.setText(R.string.no_chats);
            txtEmptyState.setVisibility(View.VISIBLE);
        } else {
            recyclerChats.setVisibility(View.VISIBLE);
            txtEmptyState.setVisibility(View.GONE);
            chatAdapter.setChats(chats);
        }
    }

    /**
     * Load sample data for demonstration
     */
    private void loadSampleData() {
        // Check if we already have chats
        java.util.List<Chat> existingChats = chatRepository.getAllChats();
        if (!existingChats.isEmpty()) {
            return;
        }

        // Create sample chats
        String currentUserId = "me";

        Chat chat1 = chatRepository.createChat("أحمد محمد", "user_001");
        if (chat1 != null) {
            chatRepository.sendMessage(chat1.getId(), currentUserId, "مرحباً! كيف حالك؟");
            chatRepository.receiveMessage(chat1.getId(), "user_001", "أنا بخير، شكراً! وأنت؟");
            chatRepository.sendMessage(chat1.getId(), currentUserId, "أنا أيضاً بخير والحمد لله");
        }

        Chat chat2 = chatRepository.createChat("سارة أحمد", "user_002");
        if (chat2 != null) {
            chatRepository.receiveMessage(chat2.getId(), "user_002", "هل ستصلين في الموعد؟");
        }

        Chat chat3 = chatRepository.createChat("عمر خالد", "user_003");
        if (chat3 != null) {
            chatRepository.sendMessage(chat3.getId(), currentUserId, "مبارك عليك الوظيفة الجديدة!");
            chatRepository.receiveMessage(chat3.getId(), "user_003", "شكراً جزيلاً لك!");
        }

        // Refresh list
        loadChats();
    }

    @Override
    public void onChatClick(Chat chat) {
        // Open chat conversation
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("chat_id", chat.getId());
        intent.putExtra("chat_name", chat.getName());
        startActivity(intent);
    }

    @Override
    public void onChatLongClick(Chat chat) {
        // Show options dialog
        new AlertDialog.Builder(this)
                .setTitle(chat.getName())
                .setItems(new String[]{"أرشفة", "حذف"}, (dialog, which) -> {
                    if (which == 1) {
                        // Delete chat
                        chatRepository.deleteChat(chat.getId());
                        loadChats();
                    }
                })
                .show();
    }
}
