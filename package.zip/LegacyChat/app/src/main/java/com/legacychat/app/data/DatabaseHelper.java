package com.legacychat.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.legacychat.app.models.Chat;
import com.legacychat.app.models.Message;

import java.util.ArrayList;
import java.util.List;

/**
 * SQLite Database Helper for LegacyChat
 * Handles all database operations for chats and messages
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "legacy_chat.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    public static final String TABLE_CHATS = "chats";
    public static final String TABLE_MESSAGES = "messages";

    // Common columns
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TIMESTAMP = "timestamp";

    // Chats table columns
    public static final String COLUMN_CHAT_NAME = "name";
    public static final String COLUMN_CHAT_PARTICIPANT_ID = "participant_id";
    public static final String COLUMN_LAST_MESSAGE = "last_message";
    public static final String COLUMN_UNREAD_COUNT = "unread_count";

    // Messages table columns
    public static final String COLUMN_CHAT_ID = "chat_id";
    public static final String COLUMN_SENDER_ID = "sender_id";
    public static final String COLUMN_CONTENT = "content";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_IS_SENT = "is_sent";

    // Create tables SQL
    private static final String CREATE_TABLE_CHATS = "CREATE TABLE " + TABLE_CHATS + " ("
            + COLUMN_ID + " TEXT PRIMARY KEY, "
            + COLUMN_CHAT_NAME + " TEXT, "
            + COLUMN_CHAT_PARTICIPANT_ID + " TEXT, "
            + COLUMN_LAST_MESSAGE + " TEXT, "
            + COLUMN_TIMESTAMP + " INTEGER, "
            + COLUMN_UNREAD_COUNT + " INTEGER DEFAULT 0"
            + ")";

    private static final String CREATE_TABLE_MESSAGES = "CREATE TABLE " + TABLE_MESSAGES + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_CHAT_ID + " TEXT, "
            + COLUMN_SENDER_ID + " TEXT, "
            + COLUMN_CONTENT + " TEXT, "
            + COLUMN_TIMESTAMP + " INTEGER, "
            + COLUMN_STATUS + " INTEGER DEFAULT 0, "
            + COLUMN_IS_SENT + " INTEGER DEFAULT 0, "
            + "FOREIGN KEY(" + COLUMN_CHAT_ID + ") REFERENCES " + TABLE_CHATS + "(" + COLUMN_ID + ")"
            + ")";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_CHATS);
        db.execSQL(CREATE_TABLE_MESSAGES);

        // Create indexes for better performance
        db.execSQL("CREATE INDEX idx_messages_chat_id ON " + TABLE_MESSAGES + "(" + COLUMN_CHAT_ID + ")");
        db.execSQL("CREATE INDEX idx_chats_timestamp ON " + TABLE_CHATS + "(" + COLUMN_TIMESTAMP + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For now, simply recreate tables on upgrade
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHATS);
        onCreate(db);
    }

    // ==================== Chat Operations ====================

    /**
     * Insert a new chat
     */
    public long insertChat(Chat chat) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, chat.getId());
        values.put(COLUMN_CHAT_NAME, chat.getName());
        values.put(COLUMN_CHAT_PARTICIPANT_ID, chat.getParticipantId());
        values.put(COLUMN_LAST_MESSAGE, chat.getLastMessage());
        values.put(COLUMN_TIMESTAMP, chat.getTimestamp());
        values.put(COLUMN_UNREAD_COUNT, chat.getUnreadCount());

        return db.insert(TABLE_CHATS, null, values);
    }

    /**
     * Get all chats ordered by timestamp
     */
    public List<Chat> getAllChats() {
        List<Chat> chats = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_CHATS,
                null,
                null,
                null,
                null,
                null,
                COLUMN_TIMESTAMP + " DESC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Chat chat = cursorToChat(cursor);
                chats.add(chat);
            }
            cursor.close();
        }

        return chats;
    }

    /**
     * Get a chat by ID
     */
    public Chat getChatById(String chatId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_CHATS,
                null,
                COLUMN_ID + " = ?",
                new String[]{chatId},
                null,
                null,
                null
        );

        Chat chat = null;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                chat = cursorToChat(cursor);
            }
            cursor.close();
        }

        return chat;
    }

    /**
     * Update chat's last message and timestamp
     */
    public int updateChatLastMessage(String chatId, String message, long timestamp) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_LAST_MESSAGE, message);
        values.put(COLUMN_TIMESTAMP, timestamp);

        return db.update(
                TABLE_CHATS,
                values,
                COLUMN_ID + " = ?",
                new String[]{chatId}
        );
    }

    /**
     * Delete a chat
     */
    public int deleteChat(String chatId) {
        SQLiteDatabase db = getWritableDatabase();

        // Delete all messages in the chat
        db.delete(TABLE_MESSAGES, COLUMN_CHAT_ID + " = ?", new String[]{chatId});

        // Delete the chat
        return db.delete(TABLE_CHATS, COLUMN_ID + " = ?", new String[]{chatId});
    }

    /**
     * Convert cursor to Chat object
     */
    private Chat cursorToChat(Cursor cursor) {
        Chat chat = new Chat();
        int indexId = cursor.getColumnIndex(COLUMN_ID);
        int indexName = cursor.getColumnIndex(COLUMN_CHAT_NAME);
        int indexParticipantId = cursor.getColumnIndex(COLUMN_CHAT_PARTICIPANT_ID);
        int indexLastMessage = cursor.getColumnIndex(COLUMN_LAST_MESSAGE);
        int indexTimestamp = cursor.getColumnIndex(COLUMN_TIMESTAMP);
        int indexUnreadCount = cursor.getColumnIndex(COLUMN_UNREAD_COUNT);

        if (indexId >= 0) chat.setId(cursor.getString(indexId));
        if (indexName >= 0) chat.setName(cursor.getString(indexName));
        if (indexParticipantId >= 0) chat.setParticipantId(cursor.getString(indexParticipantId));
        if (indexLastMessage >= 0) chat.setLastMessage(cursor.getString(indexLastMessage));
        if (indexTimestamp >= 0) chat.setTimestamp(cursor.getLong(indexTimestamp));
        if (indexUnreadCount >= 0) chat.setUnreadCount(cursor.getInt(indexUnreadCount));

        return chat;
    }

    // ==================== Message Operations ====================

    /**
     * Insert a new message
     */
    public long insertMessage(Message message) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CHAT_ID, message.getChatId());
        values.put(COLUMN_SENDER_ID, message.getSenderId());
        values.put(COLUMN_CONTENT, message.getContent());
        values.put(COLUMN_TIMESTAMP, message.getTimestamp());
        values.put(COLUMN_STATUS, message.getStatus());
        values.put(COLUMN_IS_SENT, message.isSent() ? 1 : 0);

        return db.insert(TABLE_MESSAGES, null, values);
    }

    /**
     * Get all messages for a chat
     */
    public List<Message> getMessagesForChat(String chatId) {
        List<Message> messages = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_MESSAGES,
                null,
                COLUMN_CHAT_ID + " = ?",
                new String[]{chatId},
                null,
                null,
                COLUMN_TIMESTAMP + " ASC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Message message = cursorToMessage(cursor);
                messages.add(message);
            }
            cursor.close();
        }

        return messages;
    }

    /**
     * Get message count for a chat
     */
    public int getMessageCount(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_MESSAGES + " WHERE " + COLUMN_CHAT_ID + " = ?",
                new String[]{chatId}
        );

        int count = 0;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }

        return count;
    }

    /**
     * Update message status
     */
    public int updateMessageStatus(long messageId, int status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STATUS, status);

        return db.update(
                TABLE_MESSAGES,
                values,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(messageId)}
        );
    }

    /**
     * Delete all messages for a chat
     */
    public int deleteMessagesForChat(String chatId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_MESSAGES, COLUMN_CHAT_ID + " = ?", new String[]{chatId});
    }

    /**
     * Convert cursor to Message object
     */
    private Message cursorToMessage(Cursor cursor) {
        Message message = new Message();
        int indexId = cursor.getColumnIndex(COLUMN_ID);
        int indexChatId = cursor.getColumnIndex(COLUMN_CHAT_ID);
        int indexSenderId = cursor.getColumnIndex(COLUMN_SENDER_ID);
        int indexContent = cursor.getColumnIndex(COLUMN_CONTENT);
        int indexTimestamp = cursor.getColumnIndex(COLUMN_TIMESTAMP);
        int indexStatus = cursor.getColumnIndex(COLUMN_STATUS);
        int indexIsSent = cursor.getColumnIndex(COLUMN_IS_SENT);

        if (indexId >= 0) message.setId(cursor.getLong(indexId));
        if (indexChatId >= 0) message.setChatId(cursor.getString(indexChatId));
        if (indexSenderId >= 0) message.setSenderId(cursor.getString(indexSenderId));
        if (indexContent >= 0) message.setContent(cursor.getString(indexContent));
        if (indexTimestamp >= 0) message.setTimestamp(cursor.getLong(indexTimestamp));
        if (indexStatus >= 0) message.setStatus(cursor.getInt(indexStatus));
        if (indexIsSent >= 0) message.setSent(cursor.getInt(indexIsSent) == 1);

        return message;
    }
}
