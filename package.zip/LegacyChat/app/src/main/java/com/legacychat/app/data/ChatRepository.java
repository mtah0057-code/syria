package com.legacychat.app.data;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;

import com.legacychat.app.models.Chat;
import com.legacychat.app.models.Contact;
import com.legacychat.app.models.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Repository class for managing chat data operations
 */
public class ChatRepository {

    private final DatabaseHelper databaseHelper;
    private final Context context;

    public ChatRepository(Context context) {
        this.context = context.getApplicationContext();
        this.databaseHelper = DatabaseHelper.getInstance(this.context);
    }

    // ==================== Chat Operations ====================

    /**
     * Create a new chat
     */
    public Chat createChat(String participantName, String participantId) {
        String chatId = UUID.randomUUID().toString();
        Chat chat = new Chat(chatId, participantName, participantId);

        long result = databaseHelper.insertChat(chat);
        if (result != -1) {
            return chat;
        }
        return null;
    }

    /**
     * Get all chats
     */
    public List<Chat> getAllChats() {
        return databaseHelper.getAllChats();
    }

    /**
     * Get chat by ID
     */
    public Chat getChatById(String chatId) {
        return databaseHelper.getChatById(chatId);
    }

    /**
     * Delete a chat
     */
    public boolean deleteChat(String chatId) {
        int result = databaseHelper.deleteChat(chatId);
        return result > 0;
    }

    // ==================== Message Operations ====================

    /**
     * Send a message
     */
    public Message sendMessage(String chatId, String senderId, String content) {
        Message message = new Message(chatId, senderId, content, true);

        // Insert message into database
        long messageId = databaseHelper.insertMessage(message);

        if (messageId != -1) {
            message.setId(messageId);

            // Update chat's last message
            databaseHelper.updateChatLastMessage(chatId, content, message.getTimestamp());

            return message;
        }

        return null;
    }

    /**
     * Receive a message (for simulation)
     */
    public Message receiveMessage(String chatId, String senderId, String content) {
        Message message = new Message(chatId, senderId, content, false);
        message.setStatus(Message.STATUS_DELIVERED);

        // Insert message into database
        long messageId = databaseHelper.insertMessage(message);

        if (messageId != -1) {
            message.setId(messageId);

            // Update chat's last message
            databaseHelper.updateChatLastMessage(chatId, content, message.getTimestamp());

            return message;
        }

        return null;
    }

    /**
     * Get all messages for a chat
     */
    public List<Message> getMessagesForChat(String chatId) {
        return databaseHelper.getMessagesForChat(chatId);
    }

    /**
     * Update message status
     */
    public boolean updateMessageStatus(long messageId, int status) {
        int result = databaseHelper.updateMessageStatus(messageId, status);
        return result > 0;
    }

    // ==================== Contact Operations ====================

    /**
     * Get all contacts from device
     */
    public List<Contact> getDeviceContacts() {
        List<Contact> contacts = new ArrayList<>();
        ContentResolver contentResolver = context.getContentResolver();

        String[] projection = {
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts.PHOTO_URI
        };

        Cursor cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                projection,
                null,
                null,
                ContactsContract.Contacts.DISPLAY_NAME + " ASC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                String photoUri = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.PHOTO_URI));

                // Get phone number
                String phoneNumber = getPhoneNumber(contentResolver, contactId);

                if (phoneNumber != null) {
                    Contact contact = new Contact(contactId, name, phoneNumber);
                    contact.setPhotoUri(photoUri);
                    contacts.add(contact);
                }
            }
            cursor.close();
        }

        return contacts;
    }

    /**
     * Get phone number for a contact
     */
    private String getPhoneNumber(ContentResolver contentResolver, String contactId) {
        Cursor phoneCursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{contactId},
                null
        );

        String phoneNumber = null;
        if (phoneCursor != null) {
            if (phoneCursor.moveToFirst()) {
                phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex(
                        ContactsContract.CommonDataKinds.Phone.NUMBER));
            }
            phoneCursor.close();
        }

        return phoneNumber;
    }

    /**
     * Search contacts by name
     */
    public List<Contact> searchContacts(String query) {
        List<Contact> allContacts = getDeviceContacts();
        List<Contact> filteredContacts = new ArrayList<>();

        if (query == null || query.trim().isEmpty()) {
            return allContacts;
        }

        String lowerQuery = query.toLowerCase().trim();
        for (Contact contact : allContacts) {
            String name = contact.getName();
            String phoneNumber = contact.getPhoneNumber();

            if ((name != null && name.toLowerCase().contains(lowerQuery)) ||
                (phoneNumber != null && phoneNumber.contains(query))) {
                filteredContacts.add(contact);
            }
        }

        return filteredContacts;
    }
}
