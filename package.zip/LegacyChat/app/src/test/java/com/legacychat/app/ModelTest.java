package com.legacychat.app;

import com.legacychat.app.models.Chat;
import com.legacychat.app.models.Contact;
import com.legacychat.app.models.Message;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Unit tests for LegacyChat models
 */
public class ModelTest {

    @Test
    public void message_creation() {
        Message message = new Message("chat_001", "user_001", "Hello, World!", true);

        assertNotNull(message);
        assertEquals("chat_001", message.getChatId());
        assertEquals("user_001", message.getSenderId());
        assertEquals("Hello, World!", message.getContent());
        assertTrue(message.isSent());
        assertEquals(Message.STATUS_SENDING, message.getStatus());
    }

    @Test
    public void message_status_constants() {
        assertEquals(0, Message.STATUS_SENDING);
        assertEquals(1, Message.STATUS_SENT);
        assertEquals(2, Message.STATUS_DELIVERED);
        assertEquals(3, Message.STATUS_READ);
    }

    @Test
    public void message_status_update() {
        Message message = new Message();

        message.setStatus(Message.STATUS_SENT);
        assertEquals(Message.STATUS_SENT, message.getStatus());

        message.setStatus(Message.STATUS_DELIVERED);
        assertEquals(Message.STATUS_DELIVERED, message.getStatus());

        message.setStatus(Message.STATUS_READ);
        assertEquals(Message.STATUS_READ, message.getStatus());
    }

    @Test
    public void chat_creation() {
        Chat chat = new Chat("chat_001", "Test User", "user_001");

        assertNotNull(chat);
        assertEquals("chat_001", chat.getId());
        assertEquals("Test User", chat.getName());
        assertEquals("user_001", chat.getParticipantId());
        assertEquals(0, chat.getUnreadCount());
        assertFalse(chat.isOnline());
    }

    @Test
    public void chat_unread_count() {
        Chat chat = new Chat();

        chat.setUnreadCount(5);
        assertEquals(5, chat.getUnreadCount());

        chat.setUnreadCount(0);
        assertEquals(0, chat.getUnreadCount());
    }

    @Test
    public void contact_display_name() {
        Contact contactWithName = new Contact("1", "John Doe", "123456");
        assertEquals("John Doe", contactWithName.getDisplayName());

        Contact contactWithoutName = new Contact("2", "", "123456");
        assertEquals("123456", contactWithoutName.getDisplayName());
    }

    @Test
    public void contact_equality() {
        Contact contact1 = new Contact("1", "John Doe", "123456");
        Contact contact2 = new Contact("1", "John Doe", "123456");
        Contact contact3 = new Contact("2", "Jane Doe", "789012");

        assertEquals(contact1, contact2);
        assertNotEquals(contact1, contact3);
    }

    @Test
    public void message_formatted_time() {
        Message message = new Message();
        // Set a specific timestamp (10:30 AM)
        message.setTimestamp(System.currentTimeMillis());

        String formattedTime = message.getFormattedTime();
        assertNotNull(formattedTime);
        assertTrue(formattedTime.contains(":"));
    }
}
