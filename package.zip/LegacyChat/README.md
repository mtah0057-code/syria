# LegacyChat - WhatsApp Clone for Android 4.4

تطبيق مراسلة خفيف الوزن مصمم خصيصاً للعمل على أجهزة أندرويد القديمة (Android 4.4 KitKat وما فوق).

## المميزات

- **واجهة بسيطة وأنيقة**: تصميم مستوحى من WhatsApp مع ألوانه الشهيرة
- **دردشة فورية**: إرسال واستقبال الرسائل النصية
- **جهات الاتصال**: الوصول إلى دليل الهاتف لبدء محادثات جديدة
- **تخزين محلي**: قاعدة بيانات SQLite للرسائل والمحادثات
- **حجم صغير**: تطبيق خفيف مناسب للأجهزة المحدودة الموارد

## المتطلبات

- نظام أندرويد 4.4 (API 19) أو أحدث
- Java Development Kit 8
- Android Gradle Plugin 4.1.0 أو أحدث

## هيكل المشروع

```
LegacyChat/
├── app/
│   ├── src/main/
│   │   ├── java/com/legacychat/app/
│   │   │   ├── LegacyChatApp.java      # Application class
│   │   │   ├── data/                    # Data layer
│   │   │   │   ├── DatabaseHelper.java  # SQLite database
│   │   │   │   └── ChatRepository.java  # Data repository
│   │   │   ├── models/                  # Data models
│   │   │   │   ├── Chat.java
│   │   │   │   ├── Message.java
│   │   │   │   └── Contact.java
│   │   │   └── ui/
│   │   │       ├── activities/          # Activities
│   │   │       │   ├── MainActivity.java
│   │   │       │   ├── ChatActivity.java
│   │   │       │   └── NewChatActivity.java
│   │   │       └── adapters/            # RecyclerView adapters
│   │   │           ├── ChatAdapter.java
│   │   │           └── MessageAdapter.java
│   │   └── res/                         # Resources
│   │       ├── layout/                  # XML layouts
│   │       ├── drawable/                # Drawables and icons
│   │       └── values/                  # Colors, strings, themes
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle/wrapper/
```

## كيفية البناء

### 1. تثبيت المتطلبات

تأكد من تثبيت JDK 8 و Android SDK:

```bash
# التحقق من Java
java -version

# التحقق من Android SDK (يجب تعيين ANDROID_HOME)
echo $ANDROID_HOME
```

### 2. استيراد المشروع

افتح المشروع في Android Studio أو استخدم سطر الأوامر:

```bash
cd LegacyChat

# بناء المشروع
./gradlew build

# أو على Windows
gradlew.bat build
```

### 3. تشغيل التطبيق

```bash
# تشغيل على جهاز متصل
./gradlew installDebug

# أو بناء APK
./gradlew assembleDebug
```

## إعدادات البناء

### ملف local.properties

تأكد من تعيين مسار Android SDK:

```properties
sdk.dir=/path/to/android-sdk
```

### ملف gradle.properties

```properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=false
```

## الميزات التقنية

### قاعدة البيانات (SQLite)
- جدول `chats`: تخزين المحادثات
- جدول `messages`: تخزين الرسائل
- فهارس لتحسين الأداء

### التوافق مع Android 4.4
- استخدام `android.support.v7` بدلاً من AndroidX
- الحد الأدنى من SDK: 19
- دعم TLS 1.2 للخوادم الحديثة

### إدارة الأذونات
- في Android 4.4، الأذونات تُمنح عند التثبيت
- لا حاجة لطلب أذونات في وقت التشغيل

## التطوير المستقبلي

يمكن إضافة الميزات التالية:
- إرسال الصور والملفات
- تسجيل الصوت
- إشعارات Push
- تشفير الرسائل
- دعم المجموعات
- حالة الاتصال

## الترخيص

MIT License - يمكنك استخدام هذا المشروع لأي غرض.
